
def print_logo():
    f = open('logo.txt','r')
    for line in f.readlines():
        print(line)