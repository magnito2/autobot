// index.jsx
import React from "react";
import ReactDOM from "react-dom";
import App from "./react_classes/App";

ReactDOM.render(<App />, document.getElementById("content"));